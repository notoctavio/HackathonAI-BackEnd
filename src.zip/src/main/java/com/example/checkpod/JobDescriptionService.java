package com.example.checkpod;

import org.springframework.stereotype.Service;

import java.io.IOException;
import java.nio.file.*;
import java.util.ArrayList;
import java.util.List;

@Service
public class JobDescriptionService {

    private static final String JOB_DESC_DIR = "src/main/resources/txt_descriptions/";

    public List<String> loadAllDescriptions() {
        List<String> descriptions = new ArrayList<>();



        try (DirectoryStream<Path> stream = Files.newDirectoryStream(Paths.get(JOB_DESC_DIR), "*.txt")) {
            for (Path entry : stream) {


                String content = Files.readString(entry);
                descriptions.add(content);

            }
        } catch (IOException e) {

            e.printStackTrace();
            throw new RuntimeException("Eroare la citirea fișierelor din " + JOB_DESC_DIR, e);
        }

        return descriptions;
    }
}
