package com.example.checkpod;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/ai")
public class CheckController {

    @Autowired
    private GeminiService geminiService;

    @PostMapping("/check")
    public ResponseEntity<String> checkMatch(@RequestBody CheckRequest request) {
        String result = geminiService.matchCvToJobs(request.getCvText());
        return ResponseEntity.ok(result);
    }
}
