package com.example.checkpod;

public class CheckRequest {
    private String cvText;

    public String getCvText() {
        return cvText;
    }

    public void setCvText(String cvText) {
        this.cvText = cvText;
    }
}
