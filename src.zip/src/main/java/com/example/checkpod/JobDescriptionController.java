package com.example.checkpod;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/job")
public class JobDescriptionController {

    @Autowired
    private JobDescriptionService jobDescriptionService;

    @GetMapping("/descriptions")
    public ResponseEntity<List<String>> getDescriptions() {

        List<String> descriptions = jobDescriptionService.loadAllDescriptions();

        return ResponseEntity.ok(descriptions);
    }
}
